package com.example.reservation_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ReservationStatusUpdateDTO {
	private String status;

}
